* Cara Compile :

gcc battleolympia.c unit.c matriks.c player.c map.c point.c stackpoint.c pcolor.c listsirkuler.c mesinkata.c queue.c queuepoint.c mesinkar.c -o battleolympia -lm

* Cara menjalankan :

./battleolympia

* OS yang digunakan :

Linux

Driver : unittes.c
Cara compile
gcc unittes.c unit.c matriks.c player.c map.c point.c stackpoint.c pcolor.c listsirkuler.c mesinkata.c queue.c queuepoint.c mesinkar.c -o unittes -lm


* Command :

HELP : Untuk melihat command apa saja yang dapat dilakukan
MOVE : Untuk Memindahkan Unit yang telah dipilih
RECRUIT : Untuk membeli unit baru
CHANGE_UNIT : Untuk merubah Unit yang mau dipilih
ATTACK : Untuk menyerang unit lawan disekitarnya
INFO : Untuk melihat info village dan unit di suatu petak
ENDTURN : Untuk berhenti turn player
UNDO : Untuk mengembalikan unit di posisi sebelumnya
MAP : Untuk melihat kondisi map


